let errors = new Array();
document.getElementById("error").style.display = "none"; //verbergen errors
document.getElementById("goed").style.display = "none"; //verbergen van allert bij goed verlope registratie
document.getElementById("betaling").style.display = "none"; // verbergen  allert van betalingswijze
document.getElementById("bevestig").addEventListener("click", validateForm);

function validateForm() {
  document.getElementById("error").innerHTML = "";
  document.getElementById("error").style.display = "none";
  errors = [];
  //familienaam
  let name = document.getElementById("name1").value;
  checkEmptyField(name, "Het veld naam is vereist");
  //voornaam
  let firstname = document.getElementById("firstname1").value;
  checkEmptyField(firstname, "Het veld voornaam is vereist");
  //gebruikersnaam
  let username = document.getElementById("username1").value;
  checkEmptyField(username, "Het veld gebruikersnaam is vereist");
  //adres
  let adress = document.getElementById("adress1").value;
  checkEmptyField(adress, "Het veld adres is vereist");
  //land
  let land = document.getElementById("land1").value;
  checkEmptyField(land, "Het veld land is vereist");
  //provincie
  let province = document.getElementById("province1").value;
  checkEmptyField(province, "Het veld provincie is vereist");
  //email
  let Email = document.getElementById("email").value;
  checkEmptyField(Email, "Het veld email is vereist");
  validateEmail(Email);
  //betaling

  //betaal methode selectie
  let payment = validatePayment("flexRadioDefault");
  document.getElementById("betaling").innerHTML =
    "<h4>Betalingswijze</h4>" +
    "<p>" +
    "Je betalingswijze is " +
    payment +
    ".<p>";
  document.getElementById("betaling").style.display = "block";
  if (payment == undefined) {
    document.getElementById("betaling").style.display = "none";
    errors.push("Geen betaalmethode geselecteerd");
  }

  //wachtwoord
  let ww = document.getElementById("wachtwoord").value;
  checkEmptyField(ww, "het veld wachtwoord is vereist");
  if (ww.length < 7) {
    errors.push("Wachtwoord mag niet kleiner zijn dan 7 karakters");
  }

  //herhaal wachtwoord
  let hww = document.getElementById("herhaalwachtwoord").value;
  checkEmptyField(hww, "Het veld herhaal wachtwoord is vereist");
  //controle wachtwoord minimum aantal karakters
  if (hww.length < 7) {
    errors.push("Wachtwoord mag niet kleiner zijn dan 7 karakters");
  } //controle of wachtwoorden overeen komen
  if (ww != hww) {
    errors.push("Wachtwoorden komen niet overeen");
  }
  //controle op postcode
  checkPC(document.getElementById("pc").value);

  if (document.getElementById("voorwaardenbox").checked) {
    
  }else{
    errors.push("Je moet de algemene voorwaarden accepteren")
  }

  let geselcteerd = document.getElementById("land1");
            let tekst = geselcteerd.options[geselcteerd.selectedIndex].text;
            if (tekst == "Selecteer een land") {
                errors.push("Land is vereist.")
            }
            let geselecteerd2 = document.getElementById("province1");
            let tekst2 = geselecteerd2.options[geselecteerd2.selectedIndex].text;
            if (tekst2 == "Selecteer een provincie") {
                errors.push("Provincie is vereist.")
            }

  //errors
  if (errors.length != 0) {
    document.getElementById("error").style.display = "block";
    document.getElementById("betaling").style.display = "none";
    document.getElementById("error").innerHTML += "<h4>Yikes,errors...</h4>";
    for (i = 0; i < errors.length; i++) {
      document.getElementById("error").innerHTML +=
        "<p>" + errors[i].toString() + ".<p>";
    }
  } else if (errors == 0){
    document.getElementById("goed").style= "block";
  }
}

//postcode functie
function checkPC(veld) {
  if (veld < 1000 || veld > 9999) {
    errors.push("Postcode incorrect");
  }
}
//https://stackoverflow.com/questions/604167/how-can-we-access-the-value-of-a-radio-button-using-the-dom
function validatePayment(flexRadioDefault) {
  let elements = document.getElementsByName(flexRadioDefault);
  for (let i = 0, l = elements.length; i < l; i++) {
    if (elements[i].checked) {
      return elements[i].value;
    }
  }
}

//https://stackoverflow.com/questions/42965541/email-validation-javascript
function validateEmail(email) {
  var regex = /([a-z A-Z 0-9\_]{1}[a-z A-Z 0-9\.\_\-]*)@([a-z A-Z 0-9]{1}[a-z A-Z,0-9 \.\-]*)/;
  return regex.test(email);
}

function checkEmptyField(veld, melding) {
  if (veld.length == 0) {
    errors.push(melding);
  } else return;
}

//stackoverflow.com/questions/29802104/javascript-change-drop-down-box-options-based-on-another-drop-down-box-value
//https://stackoverflow.com/questions/29802104/javascript-change-drop-down-box-options-based-on-another-drop-down-box-value
window.onload = function () {
  let landen = {
    "Selecteer een land": ["Selecteer een provincie"],
    Belgie: [
      "Selecteer een provincie",
      "Antwerpen",
      "Henegouwen",
      "Limburg",
      "Luik",
      "Luxemburg",
      "Namen",
      "Oost-Vlaanderen",
      "Vlaams-Brabant",
      "West-Vlaanderen",
      "Waals-Brabant",
    ],
    Nederland: [
      "Selecteer een provincie",
      "Drenthe",
      "Flevoland",
      "Friesland",
      "Gelderland",
      "Groningen",
      "Limburg",
      "Noord-Brabant",
      "Noord-Holland",
      "Utrecht",
      "Zeeland",
      "Zuid-Holland",
    ],
    Italië: [
      "Selecteer een provincie",
      "Abruzzen",
      "Apulië",
      "Basilicata",
      "Calabrië",
      "Campania",
      "Emilia-Romagna",
      "Friuli-Venezia Giulia",
      "Lazio",
      "Lingurië",
      "Lombardije",
      "Marche",
      "Molise",
      "Piemonte",
      "Sardinië",
      "Silicië",
      "Trentino-Zuid-Tirol",
      "Toscane",
      "Umbrië",
      "Valle d'Aosta",
      "Veneto",
    ],
    Spanje: [
      "Selecteer een provincie",
      "Alava",
      "Albacete",
      "Alicante",
      "Almeria",
      "Astrurië",
      "Avila",
      "Badajoz",
      "Balearen",
      "Barcelona",
      "Biskaje",
      "Burgos",
      "Càceres",
      "Càdiz",
      "Cantabrië",
      "Castellon",
      "Ceuta",
      "Ciudad Real",
      "Cordoba",
    ],
    Turkije: [
      "Selecteer een provincie",
      "Adana",
      "Ankara",
      "Bursa",
      "Denizli",
      "Istanboel",
      "Izmir",
      "Kayseri",
      "Konya",
      "Mardin",
      "Sivas",
      "Trabzon",
      "Van",
    ],
  };

  (land_select = document.getElementById("land1")),
    (prvince_select = document.getElementById("province1"));

  setOptions(land_select, Object.keys(landen));

  setOptions(prvince_select, landen[land_select.value]);

  land_select.addEventListener("change", function () {
    setOptions(prvince_select, landen[land_select.value]);
  });

  function setOptions(select, options) {
    select.innerHTML = "";

    options.forEach(function (value) {
      select.innerHTML += '<option name="' + value + '">' + value + "</option>";
    });
  }
};
