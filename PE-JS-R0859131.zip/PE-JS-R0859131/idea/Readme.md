This is a school project for interactive website build in html and javascript.
from the IT class Thomas More Geel Belgium